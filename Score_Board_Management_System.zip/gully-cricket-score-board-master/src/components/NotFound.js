import React from 'react'

const NotFound = () => {
  return <h2>NotFound</h2>
}

export default NotFound
